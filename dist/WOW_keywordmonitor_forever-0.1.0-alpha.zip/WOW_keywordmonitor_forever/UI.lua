WOWKeywordMonitorForever = WOWKeywordMonitorForever or {}
local WKM = WOWKeywordMonitorForever

function WKM:StylePanel(frame)
    if not frame.SetBackdrop then return end
    frame:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true,
        tileSize = 32,
        edgeSize = 24,
        insets = { left = 8, right = 8, top = 8, bottom = 8 },
    })
end

function WKM:CreateButton(parent, text, width, height)
    local button = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    button:SetSize(width or 90, height or 24)
    button:SetText(text or "")
    return button
end

function WKM:CreateEditBox(parent, width, height)
    local edit = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
    edit:SetSize(width or 160, height or 24)
    edit:SetAutoFocus(false)
    edit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    edit:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    return edit
end

function WKM:SetToggleState(toggle, enabled)
    if not toggle then return end
    toggle.value = enabled and true or false

    if toggle.value then
        toggle.background:SetVertexColor(0.20, 0.72, 0.34, 0.95)
        toggle.knob:ClearAllPoints()
        toggle.knob:SetPoint("RIGHT", -3, 0)
        toggle.stateText:SetText("ON")
        toggle.stateText:ClearAllPoints()
        toggle.stateText:SetPoint("LEFT", 6, 0)
    else
        toggle.background:SetVertexColor(0.34, 0.34, 0.34, 0.95)
        toggle.knob:ClearAllPoints()
        toggle.knob:SetPoint("LEFT", 3, 0)
        toggle.stateText:SetText("OFF")
        toggle.stateText:ClearAllPoints()
        toggle.stateText:SetPoint("RIGHT", -5, 0)
    end
end

function WKM:CreateToggleSwitch(parent, enabled, onToggle)
    local toggle = CreateFrame("Button", nil, parent)
    toggle:SetSize(54, 26)
    toggle:RegisterForClicks("LeftButtonUp")

    local bg = toggle:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetTexture("Interface\\Buttons\\WHITE8x8")
    toggle.background = bg

    local knob = toggle:CreateTexture(nil, "ARTWORK")
    knob:SetSize(20, 20)
    knob:SetTexture("Interface\\Buttons\\WHITE8x8")
    knob:SetVertexColor(0.95, 0.95, 0.95, 1)
    toggle.knob = knob

    local stateText = toggle:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    stateText:SetTextColor(1, 1, 1)
    toggle.stateText = stateText

    toggle:SetScript("OnClick", function(self)
        local newValue = not self.value
        WKM:SetToggleState(self, newValue)
        if onToggle then onToggle(newValue, self) end
    end)

    self:SetToggleState(toggle, enabled)
    return toggle
end

local function addCheckLabel(check, text)
    local label = check:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    label:SetPoint("LEFT", check, "RIGHT", 2, 0)
    label:SetText(text)
    return label
end

function WKM:UpdateGlobalState()
    if not self.mainFrame then return end
    self:SetToggleState(self.mainFrame.listenSwitch, self.DB.enabled)
    self.mainFrame.soundCheck:SetChecked(self.DB.settings.sound)
    self.mainFrame.screenCheck:SetChecked(self.DB.settings.screenAlert)
    self.mainFrame.autoDeleteCheck:SetChecked(self.DB.settings.autoDeleteOldMessages)
    self.mainFrame.clientIconCheck:SetChecked(self.DB.settings.clientIconAlert)
end

function WKM:ShowTab(tabName)
    if not self.mainFrame then return end
    if self.DismissHistoryPreview then self:DismissHistoryPreview() end
    if self.friendNoteFrame then self.friendNoteFrame:Hide() end

    local showHistory = tabName == "history"
    local showBlacklist = tabName == "blacklist"
    local showRules = tabName == "rules"

    self.mainFrame.historyPanel:SetShown(showHistory)
    self.mainFrame.blacklistPanel:SetShown(showBlacklist)
    self.mainFrame.rulesPanel:SetShown(showRules)

    self.mainFrame.historyTab:SetEnabled(not showHistory)
    self.mainFrame.blacklistTab:SetEnabled(not showBlacklist)
    self.mainFrame.rulesTab:SetEnabled(not showRules)

    if showHistory then
        self:MarkRead()
        if self.RefreshHistoryUI then self:RefreshHistoryUI(true) end
    elseif showBlacklist then
        if self.RefreshBlacklistUI then self:RefreshBlacklistUI(true) end
    elseif showRules and self.RefreshRulesUI then
        self:RefreshRulesUI()
    end
end

function WKM:ToggleMainWindow()
    if not self.mainFrame then return end
    if self.mainFrame:IsShown() then
        self.mainFrame:Hide()
    else
        self.mainFrame:Show()
        self:ShowTab("history")
    end
end

function WKM:CreateMainWindow()
    if self.mainFrame then return end

    local template = BackdropTemplateMixin and "BackdropTemplate" or nil
    local frame = CreateFrame("Frame", "WOWKeywordMonitorForeverMainFrame", UIParent, template)
    frame:SetSize(860, 570)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata("DIALOG")
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:SetClampedToScreen(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    frame:Hide()
    self:StylePanel(frame)
    self.mainFrame = frame

    if UISpecialFrames then
        local found = false
        for _, frameName in ipairs(UISpecialFrames) do
            if frameName == "WOWKeywordMonitorForeverMainFrame" then
                found = true
                break
            end
        end
        if not found then
            table.insert(UISpecialFrames, "WOWKeywordMonitorForeverMainFrame")
        end
    end

    local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 22, -18)
    title:SetText("WOW Keyword Monitor - 无限服")

    local subtitle = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    subtitle:SetPoint("LEFT", title, "RIGHT", 12, 0)
    subtitle:SetText("Forever / Interface 16001")

    local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -5, -5)

    frame.listenLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    frame.listenLabel:SetPoint("TOPRIGHT", -112, -48)
    frame.listenLabel:SetText("全局监听")

    frame.listenSwitch = self:CreateToggleSwitch(frame, self.DB.enabled, function(value)
        WKM:SetEnabled(value)
    end)
    frame.listenSwitch:SetPoint("TOPRIGHT", -48, -40)

    frame.soundCheck = CreateFrame("CheckButton", nil, frame, "UICheckButtonTemplate")
    frame.soundCheck:SetPoint("TOPLEFT", 22, -48)
    addCheckLabel(frame.soundCheck, "声音提醒")
    frame.soundCheck:SetScript("OnClick", function(self)
        WKM.DB.settings.sound = self:GetChecked() and true or false
    end)

    frame.screenCheck = CreateFrame("CheckButton", nil, frame, "UICheckButtonTemplate")
    frame.screenCheck:SetPoint("LEFT", frame.soundCheck, "RIGHT", 100, 0)
    addCheckLabel(frame.screenCheck, "屏幕大字")
    frame.screenCheck:SetScript("OnClick", function(self)
        WKM.DB.settings.screenAlert = self:GetChecked() and true or false
    end)

    frame.autoDeleteCheck = CreateFrame("CheckButton", nil, frame, "UICheckButtonTemplate")
    frame.autoDeleteCheck:SetPoint("LEFT", frame.screenCheck, "RIGHT", 115, 0)
    addCheckLabel(frame.autoDeleteCheck, "自动删除 >10分钟")
    frame.autoDeleteCheck:SetScript("OnClick", function(self)
        WKM.DB.settings.autoDeleteOldMessages = self:GetChecked() and true or false
        if WKM.DB.settings.autoDeleteOldMessages then
            WKM:PruneExpiredHistory()
            if WKM.RefreshHistoryUI then WKM:RefreshHistoryUI(true) end
            if WKM.RefreshBlacklistUI then WKM:RefreshBlacklistUI(true) end
        end
    end)

    frame.clientIconCheck = CreateFrame("CheckButton", nil, frame, "UICheckButtonTemplate")
    frame.clientIconCheck:SetPoint("LEFT", frame.autoDeleteCheck, "RIGHT", 150, 0)
    addCheckLabel(frame.clientIconCheck, "Dock/任务栏提醒")
    frame.clientIconCheck:SetScript("OnClick", function(self)
        WKM.DB.settings.clientIconAlert = self:GetChecked() and true or false
    end)

    frame.historyTab = self:CreateButton(frame, "匹配消息", 110, 26)
    frame.historyTab:SetPoint("TOPLEFT", 22, -82)
    frame.historyTab:SetScript("OnClick", function() WKM:ShowTab("history") end)

    frame.blacklistTab = self:CreateButton(frame, "黑名单消息", 120, 26)
    frame.blacklistTab:SetPoint("LEFT", frame.historyTab, "RIGHT", 6, 0)
    frame.blacklistTab:SetScript("OnClick", function() WKM:ShowTab("blacklist") end)

    frame.rulesTab = self:CreateButton(frame, "规则设置", 110, 26)
    frame.rulesTab:SetPoint("LEFT", frame.blacklistTab, "RIGHT", 6, 0)
    frame.rulesTab:SetScript("OnClick", function() WKM:ShowTab("rules") end)

    frame.historyPanel = CreateFrame("Frame", nil, frame)
    frame.historyPanel:SetPoint("TOPLEFT", 18, -115)
    frame.historyPanel:SetPoint("BOTTOMRIGHT", -18, 18)

    frame.blacklistPanel = CreateFrame("Frame", nil, frame)
    frame.blacklistPanel:SetPoint("TOPLEFT", 18, -115)
    frame.blacklistPanel:SetPoint("BOTTOMRIGHT", -18, 18)

    frame.rulesPanel = CreateFrame("Frame", nil, frame)
    frame.rulesPanel:SetPoint("TOPLEFT", 18, -115)
    frame.rulesPanel:SetPoint("BOTTOMRIGHT", -18, 18)

    if self.CreateHistoryPanel then self:CreateHistoryPanel(frame.historyPanel) end
    if self.CreateBlacklistPanel then self:CreateBlacklistPanel(frame.blacklistPanel) end
    if self.CreateRulesPanel then self:CreateRulesPanel(frame.rulesPanel) end

    frame:SetScript("OnShow", function()
        WKM:UpdateGlobalState()
        WKM:ShowTab("history")
    end)
    frame:SetScript("OnHide", function()
        -- Close both transient UI surfaces even when dismissed via ESC.
        if WKM.DismissHistoryPreview then WKM:DismissHistoryPreview() end
        if WKM.friendNoteFrame then WKM.friendNoteFrame:Hide() end
    end)

    self:UpdateGlobalState()
    self:ShowTab("history")
end
